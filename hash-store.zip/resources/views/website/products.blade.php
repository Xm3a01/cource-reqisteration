@extends('layouts.app')

@section('content')
<vue-product />
@endsection