@extends('layouts.app')

@section('content')
<vue-contact />
@endsection