@extends('layouts.app')

@section('content')
<vue-page />  
@endsection