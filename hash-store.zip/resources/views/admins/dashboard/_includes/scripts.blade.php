{{-- <footer class="footer">
    <span class="text-left">
        <a href="http://coreui.io">CoreUI</a> &copy; 2016 creativeLabs.
    </span>
    <span class="pull-right">
        Powered by <a href="http://coreui.io">CoreUI</a>
    </span>
</footer> --}}
<!-- Bootstrap and necessary plugins -->
<script src="{{asset('vendor/js/libs/jquery.min.js')}}"></script>
<script src="{{asset('vendor/js/libs/tether.min.js')}}"></script>
<script src="{{asset('vendor/js/libs/bootstrap.min.js')}}"></script>
<script src="{{asset('vendor/js/libs/pace.min.js')}}"></script>

<!-- Plugins and scripts required by all views -->
<script src="{{asset('vendor/js/libs/Chart.min.js')}}"></script>

<!-- CoreUI main scripts -->

<script src="{{asset('vendor/js/app.js')}}"></script>

<!-- Plugins and scripts required by this views -->
<!-- Custom scripts required by this view -->
<script src="{{asset('vendor/js/views/main.js')}}"></script>

<script src="{{asset('vendor/js/toastr.min.js')}}" type="text/javascript"></script>
<script src="{{asset('vendor/js/ui-toastr.min.js')}}" type="text/javascript"></script>
<!-- Grunt watch plugin -->
{{-- <script src="//localhost:35729/livereload.js"></script> --}}