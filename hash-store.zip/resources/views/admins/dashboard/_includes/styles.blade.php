 <!-- Icons -->
 <link href="{{asset('/vendor/css/font-awesome.min.css')}}" rel="stylesheet">
 <link href="{{asset('/vendor/css/simple-line-icons.css')}}" rel="stylesheet">
 <!-- Main styles for this application -->
 <link href="{{asset('/vendor/dest/style.css')}}" rel="stylesheet">
 <link href="{{asset('vendor/css/toastr-rtl.min.css')}}" rel="stylesheet" type="text/css" />
