<template>
    <div class="bg-white p-6 rounded shadow">
        <slot></slot>
    </div>
</template>

<script>
    export default {
        name: "BasePanel"
    }
</script>

<style scoped>

</style>
