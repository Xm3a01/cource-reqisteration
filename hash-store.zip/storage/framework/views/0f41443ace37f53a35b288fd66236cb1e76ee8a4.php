<script>
    toastr.options = {
        "closeButton": false,
        "newestOnTop": false,
        "progressBar": false,
        "positionClass": "toast-top-left",
        "preventDuplicates": false,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    };

    <?php if(count($errors->all())): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            toastr.error('<?php echo e($error); ?>', {timeOut: 5000});
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <?php if(Session::has('error')): ?>
        toastr.error("<?php echo e(Session::get('error')); ?>", {timeOut: 5000});
    <?php elseif(Session::has('success')): ?>
        toastr.success("<?php echo e(Session::get('success')); ?>", {timeOut: 5000});
    <?php endif; ?>
</script><?php /**PATH F:\Projects\hash-store\resources\views/admins/dashboard/_includes/messages.blade.php ENDPATH**/ ?>