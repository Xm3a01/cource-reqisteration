

<?php $__env->startSection('content'); ?>
    
<div class="container-fluid">

    <div class="animated fadeIn">
        <div class="row">
            
            <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <a class="nav-link " href="<?php echo e(route('categories.create')); ?>"><button class="btn btn-primary" > + اضافة </button></a>

                         <i class="fa fa-align-justify"></i>    كل التصنيفات  
                    </div>
                    <div class="card-block">
                        <table class="table table-bordered table-striped table-condensed">
                            <thead>
                                <tr>
                                <th>رقم الصنف</th> 
                                <th>اسم الصنف</th> 
                                <th>الوصف</th>
                                <th>الصورة</th>
                                <th>العمليات</th>
                                   
                                   
                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                                <tr>
                                     <td><?php echo e($category->id); ?></td>
                                     <td><?php echo e($category->name); ?></td>
                                     <td><?php echo e($category->description); ?></td>
                                     <td><img src="<?php echo e($category->image); ?>" height="40" width="40" alt="" style="border-radius: 50%"></td>
                                     <td>
                                         <form action="<?php echo e(route('categories.destroy' , $category->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <a style="color:white" class="nav-link btn  btn-info"  href="<?php echo e(route('categories.edit' , $category->id)); ?>"><i class="fa fa-edit"></i></a>
                                            <button class="btn btn-danger nav-link" type="submit" ><i class="fa fa-trash"></i></button>
                                        </form>
                                     </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                           </div>
                               <!--/row-->
                        <!--/.row-->
                        <br/>
                                                                    
                    </div>
                </div>
            </div>
            <!--/.col-->
        </div>
        <!--/.row-->
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\hash-store\resources\views/admins/dashboard/categories/index.blade.php ENDPATH**/ ?>