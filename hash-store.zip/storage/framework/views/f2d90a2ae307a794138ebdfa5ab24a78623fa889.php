

<?php $__env->startSection('content'); ?>
<vue-contact />
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\hash-store\resources\views/website/contact.blade.php ENDPATH**/ ?>