<?php echo e($slot); ?>

<?php /**PATH F:\Projects\hash-store\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>