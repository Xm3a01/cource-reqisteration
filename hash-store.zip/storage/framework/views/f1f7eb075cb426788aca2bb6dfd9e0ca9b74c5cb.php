


<?php $__env->startSection('content'); ?>
<div class="min-h-screen flex items-center">
    <div class="bg-white w-full max-w-lg rounded-lg shadow overflow-hidden mx-auto">
        <div class="py-4 px-6">
            <div class="text-center font-bold text-gray-700 text-3xl">Hash</div>
            <div class="mt-1 text-center font-bold text-gray-600 text-xl">Admin Login</div>
            <form action="<?php echo e(route('admins.login')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mt-4 w-full">
                    <input type="email" name="email" placeholder="Email address"
                           class="w-full mt-2 py-3 px-4 bg-gray-100 text-gray-700 border border-gray-300 rounded  block appearance-none placeholder-gray-500 focus:outline-none focus:bg-white"/>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-xs mt-4">
                        <?php echo e($message); ?>

                    </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mt-4 w-full">
                    <input type="password" name="password" placeholder="Password"
                           class="w-full mt-2 py-3 px-4 bg-gray-100 text-gray-700 border border-gray-300 rounded  block appearance-none placeholder-gray-500 focus:outline-none focus:bg-white"/>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-xs italic mt-4">
                        <?php echo e($message); ?>

                    </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="flex justify-between items-center mt-6">
                    
                    <button type="submit"
                            class="py-2 px-4 bg-blue-500 text-white rounded hover:bg-green-400 focus:outline-none">
                        Login
                    </button>
                </div>
            </form>
        </div>
        <div class="flex items-center justify-center py-4 bg-gray-100 text-center">
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\hash-store\resources\views/admins/auth/Login.blade.php ENDPATH**/ ?>