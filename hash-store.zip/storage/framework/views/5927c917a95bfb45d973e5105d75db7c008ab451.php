

<?php $__env->startSection('content'); ?>
<header>
    <!-- TOP HEADER -->
    <div id="top-header">
        <div class="container">
            <ul class="header-links pull-left">
                <li><a href="#"><i class="fa fa-phone"></i>  </a></li>
                <li><a href="#"><i class="fa fa-envelope-o"></i> email@email.com</a></li>
                <li><a href="#"><i class="fa fa-map-marker"></i> Al Siteen St, Khartoum, Sudan </a></li>
            </ul>
            <?php if(Auth::check()): ?>
            <ul class="header-links pull-right">
                <li><a href="#"><i ></i> <?php echo e(Auth::user()->name); ?> </a></li>
                <li><a href="#"><i ></i> <img  :src="user.avatar" alt="" class="avatar"> </a></li>
            </ul>
            <?php else: ?>
            <ul class="header-links pull-right" v-if="!user">
                <li><a href="/login"><i ></i> Login </a></li>
                <li><a href="/register"><i ></i> Register </a></li>
            </ul>
            <?php endif; ?>
        </div>
    </div>
    <!-- /TOP HEADER -->
</header>

<div class="section">
    <!-- container -->
    <form action="<?php echo e(route('login')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="container">
        <!-- row -->
    <div class="row">

        <div class="col-md-5"></div>
        <div class="col-md-7" style="direction: rtl">
            <!-- Billing Details -->
            <div class="billing-details">
                <div class="section-title">
                    <h3 class="title">Login</h3>
                </div>
                <div class="form-group">
                    <input type="email" name="email" placeholder="Email address"
                    class="input"/>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-4" style="color: red">
                        <?php echo e($message); ?>

                    </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            
            
                <div class="form-group">
                    <input type="password" name="password" placeholder="Password"
                               class="input"/>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-4" style="color: red">
                            <?php echo e($message); ?>

                        </p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
            </div>
            
                
            <button type="submit" class="primary-btn order-submit">Login</button>
            </div>
        </div>
            
     </div>
    </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\hash-store\resources\views/auth/signin.blade.php ENDPATH**/ ?>