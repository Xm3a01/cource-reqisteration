<tr>
<td class="header">
<a href="<?php echo e($url); ?>" style="display: inline-block;">
<?php if(trim($slot) === 'HashZo'): ?>
<span style="font-size: 16px;">HashZo</span>
<?php else: ?>
<?php echo e($slot); ?>

<?php endif; ?>
</a>
</td>
</tr>
<?php /**PATH F:\Projects\hash-store\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>