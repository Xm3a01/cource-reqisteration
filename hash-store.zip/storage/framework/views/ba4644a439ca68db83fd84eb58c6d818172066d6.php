

<?php $__env->startSection('content'); ?>

        <div class="container-fluid">

            <div class="animated fadeIn">
                <div class="row">
                    
                    <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <a class="nav-link btn btn-primary" href="<?php echo e(route('admins.create')); ?>"> + اضافة </a>

                                 <i class="fa fa-align-justify"></i>    كل المشرفين  
                            </div>
                            <div class="card-block">
                                <table class="table table-bordered table-striped table-condensed">
                                    <thead>
                                        <tr>
                                        <th> الصوره </th>
                                        <th>رقم المشرف </th> 
                                        <th>اسم المشرف </th>
                                        <th>عنوان البريد </th>
                                        <th>رقم الهاتف </th> 
                                        <th> كميه المبيعات </th> 
                                        
                                        
                                        <th>العمليات</th>
                                           
                                           
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><img src="<?php echo e($admin->avatar); ?>" height="40" width="40" style="border-radius: 50%" alt=""></td>
                                            <td><?php echo e($index + 1); ?></td>
                                            <td><?php echo e($admin->name); ?></td>
                                            <td><?php echo e($admin->email); ?></td>
                                            <td><?php echo e($admin->phone); ?></td>
                                            <td><?php echo e($admin->totalPayment); ?></td>
                                            <td>
                                                <form action="<?php echo e(route('admins.destroy' , $admin->id)); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <a style="color:white" class="nav-link btn  btn-info"  href="<?php echo e(route('admins.edit' , $admin->id)); ?>"><i class="fa fa-edit"></i></a>
                                                    <button class="btn btn-danger nav-link" type="submit" ><i class="fa fa-trash"></i></button>
                                                </form>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>

                    

                                 </div>
                               <!--/row-->

                
                                <!--/.row-->
                                <br/>
                                                                            
                            </div>
                        </div>
                    </div>
                    <!--/.col-->
                </div>
                <!--/.row-->
            </div>

        </div>
        <!--/.container-fluid-->
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admins.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\hash-store\resources\views/admins/dashboard/admins/index.blade.php ENDPATH**/ ?>